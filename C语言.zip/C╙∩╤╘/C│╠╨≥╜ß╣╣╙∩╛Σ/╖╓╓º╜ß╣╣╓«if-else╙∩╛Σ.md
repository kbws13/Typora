# 分支结构之if-else语句

基本结构：

```c
if（表达式）{
	执行代码块1；
}
else{
	执行代码块2；
}
```

语义为：如果表达式的值为真，则执行代码块1，否则执行代码块2 

![1652172546231](https://gitee.com/Enteral/images/raw/master/https://gitee.com/enteral/images/1652172546231.png)

