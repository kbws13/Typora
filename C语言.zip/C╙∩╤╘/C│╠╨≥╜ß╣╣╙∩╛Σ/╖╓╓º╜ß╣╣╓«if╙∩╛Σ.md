# 分支结构之if语句

语句基本结构：

```c
if(表达式){
    执行代码块;
}
```

语义为：如果表达式的值为真，则执行代码块的内容，否则不执行 

![1652172456834](https://gitee.com/Enteral/images/raw/master/https://gitee.com/enteral/images/1652172456834.png)

