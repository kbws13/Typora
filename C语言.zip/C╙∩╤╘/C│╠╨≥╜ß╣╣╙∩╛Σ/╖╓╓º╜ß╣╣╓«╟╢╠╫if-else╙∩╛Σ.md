# 分支结构之嵌套if-else语句 

格式为：

```c
if(表达式)
{
    if（表达式）
    {
        执行代码块；
    }
    else
    {
        执行代码块；
    }
}else{
	执行代码块；
}
```

![1652172718786](https://gitee.com/Enteral/images/raw/master/https://gitee.com/enteral/images/1652172718786.png)

