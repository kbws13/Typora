# 分支结构之多重if-else语句 

结构：

```c
if(表达式1){
	执行代码块1；
}else if（表达式m）{
	执行代码块m；
}
…………
else{
	执行代码块n;
}
```

其语义为：依次判断表达式的值，当出现某个值为真时，则执行对应代码块，否则执行代码块n。 

![1652172639718](https://gitee.com/Enteral/images/raw/master/https://gitee.com/enteral/images/1652172639718.png)

