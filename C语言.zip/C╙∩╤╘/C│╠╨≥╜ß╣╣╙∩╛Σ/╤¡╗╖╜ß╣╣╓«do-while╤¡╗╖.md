# 循环结构之do-while循环 

结构：

```c
do
{
    执行代码块；
}while(表达式)；
```

如图所示：

![1652172899909](https://gitee.com/Enteral/images/raw/master/https://gitee.com/enteral/images/1652172899909.png)

==注：do-while循环至少要执行一次循环语句==

