# C程序结构 

一个C程序由若干头文件和函数组成 

```c
#include<stdio.h> //包含头文件
//主函数
int main(){
    printf("Hello World");
    return 0;
}
```

**include<stdio.h>是一条预处理命令，通知C语言编译系统在对C程序进行正式编译之前需要做一些预处理工作函数是实现代码逻辑的一个小单元**

