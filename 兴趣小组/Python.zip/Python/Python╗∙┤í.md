# 数据类型和变量


# 字符串和编码



# 使用list和tuple



# 条件判断



# 循环



# 使用dict和set