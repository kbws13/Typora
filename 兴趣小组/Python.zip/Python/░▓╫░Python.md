因为Python是跨平台的，它可以运行在Windows、Mac和各种Linux/Unix系统上。在Windows上写Python程序，放到Linux上也是能够运行的。

要开始学习Python编程，首先就得把Python安装到你的电脑里。安装后，你会得到Python解释器（就是负责运行Python程序的），一个命令行交互环境，还有一个简单的集成开发环境。

# 安装Python 3.10
目前，Python有两个版本，一个是2.x版，一个是3.x版，这两个版本是不兼容的。由于3.x版越来越普及，我们的教程将以最新的Python 3.8版本为基础。
## Windows上安装Python

[64位安装程序](https://www.python.org/ftp/python/3.10.8/python-3.10.8-amd64.exe)

[32位安装程序](https://www.python.org/ftp/python/3.10.8/python-3.10.8.exe)


## Mac上安装Python


[安装程序](https://www.python.org/ftp/python/3.10.8/python-3.10.8-macos11.pkg)

